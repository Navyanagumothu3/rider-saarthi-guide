import { useNavigate, useLocation } from "react-router-dom";
import { CheckCircle2, ArrowLeft, Bike } from "lucide-react";
import StepIndicator from "@/components/StepIndicator";

const defaultPlan = { id: "medium", label: "Medium", price: 30, coverage: "₹350/day", payout: 350 };

const Payout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const plan = (location.state as any)?.plan ?? defaultPlan;

  return (
    <div className="min-h-screen bg-background flex flex-col items-center px-4 py-6 max-w-md mx-auto">
      <div className="flex items-center gap-2 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
          <Bike className="w-5 h-5 text-primary-foreground" />
        </div>
        <h1 className="text-xl font-bold text-foreground">RiderSaarthi AI</h1>
      </div>

      <StepIndicator currentStep={3} steps={["Plan", "Claim", "Payout"]} />

      <div className="w-20 h-20 rounded-full bg-primary/15 flex items-center justify-center mb-4 animate-pulse">
        <CheckCircle2 className="w-10 h-10 text-primary" />
      </div>

      <h2 className="text-2xl font-bold text-foreground mb-1">Claim Processed ✅</h2>
      <p className="text-sm text-muted-foreground mb-8">Your payout has been approved</p>

      <div className="w-full bg-card rounded-2xl border border-border shadow-lg p-6 mb-6 text-center">
        <p className="text-sm text-muted-foreground mb-1">Amount Credited</p>
        <p className="text-4xl font-extrabold text-primary mb-1">₹{plan.payout}</p>
        <p className="text-xs text-muted-foreground">to your UPI • same day</p>

        <div className="h-px bg-border my-5" />

        <div className="space-y-3 text-left">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Claim ID</span>
            <span className="font-medium text-card-foreground">#RS-20260320</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Reason</span>
            <span className="font-medium text-card-foreground">🌧️ Heavy Rain</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Plan</span>
            <span className="font-medium text-card-foreground">{plan.label} Cover</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Status</span>
            <span className="font-medium text-primary">Paid ✅</span>
          </div>
        </div>
      </div>

      <button
        onClick={() => navigate("/")}
        className="w-full py-3.5 rounded-xl bg-secondary text-secondary-foreground font-semibold flex items-center justify-center gap-2 mb-3"
      >
        View History
      </button>
      <button
        onClick={() => navigate("/")}
        className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </button>
    </div>
  );
};

export default Payout;
