import { useNavigate, useLocation } from "react-router-dom";
import { CloudRain, AlertTriangle, ChevronRight, Bike } from "lucide-react";
import StepIndicator from "@/components/StepIndicator";

const defaultPlan = { id: "medium", label: "Medium", price: 30, coverage: "₹350/day", payout: 350, emoji: "🛡️🛡️" };

const Status = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const plan = (location.state as any)?.plan ?? defaultPlan;

  return (
    <div className="min-h-screen bg-background flex flex-col items-center px-4 py-6 max-w-md mx-auto">
      <div className="flex items-center gap-2 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
          <Bike className="w-5 h-5 text-primary-foreground" />
        </div>
        <h1 className="text-xl font-bold text-foreground">RiderSaarthi AI</h1>
      </div>

      <StepIndicator currentStep={2} steps={["Plan", "Claim", "Payout"]} />

      <div className="w-full bg-primary/10 rounded-xl p-4 flex items-center gap-3 mb-6">
        <span className="text-2xl">✅</span>
        <div>
          <p className="font-semibold text-foreground text-sm">{plan.label} Cover Active</p>
          <p className="text-xs text-muted-foreground">₹{plan.price}/week • Up to {plan.coverage}</p>
        </div>
      </div>

      <div className="w-full bg-card rounded-2xl border border-border shadow-lg p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <CloudRain className="w-5 h-5 text-warning" />
          <p className="font-semibold text-card-foreground">Weather Alert</p>
        </div>
        <div className="bg-warning/10 rounded-xl p-4 mb-4">
          <p className="text-3xl mb-1">🌧️</p>
          <p className="font-bold text-foreground text-lg">Heavy Rain Detected</p>
          <p className="text-sm text-muted-foreground mt-1">
            Rainfall above 50mm in your Hyderabad delivery zone. Expected payout: <span className="font-semibold text-primary">₹{plan.payout}</span>
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
          <AlertTriangle className="w-3 h-3" />
          <span>AI verified via weather API + GPS data</span>
        </div>

        <button
          onClick={() => navigate("/payout", { state: { plan } })}
          className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
        >
          File Claim — ₹{plan.payout} <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <button
        onClick={() => navigate("/fraud-alert")}
        className="w-full bg-warning/10 border border-warning/30 rounded-xl p-4 flex items-center gap-3 text-left"
      >
        <span className="text-xl">⚠️</span>
        <div className="flex-1">
          <p className="text-sm font-semibold text-foreground">View Flagged Claims</p>
          <p className="text-xs text-muted-foreground">See how fraud detection works</p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground" />
      </button>
    </div>
  );
};

export default Status;
