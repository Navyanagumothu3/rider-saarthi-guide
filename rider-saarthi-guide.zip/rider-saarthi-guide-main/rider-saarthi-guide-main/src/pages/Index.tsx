import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Bike, ChevronRight } from "lucide-react";
import StepIndicator from "@/components/StepIndicator";

const plans = [
  { id: "low", label: "Low", price: 20, coverage: "₹200/day", payout: 200, emoji: "🛡️" },
  { id: "medium", label: "Medium", price: 30, coverage: "₹350/day", payout: 350, emoji: "🛡️🛡️" },
  { id: "high", label: "High", price: 50, coverage: "₹500/day", payout: 500, emoji: "🛡️🛡️🛡️" },
];

const Index = () => {
  const navigate = useNavigate();
  const [selected, setSelected] = useState("medium");

  const selectedPlan = plans.find((p) => p.id === selected)!;

  return (
    <div className="min-h-screen bg-background flex flex-col items-center px-4 py-6 max-w-md mx-auto">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
          <Bike className="w-5 h-5 text-primary-foreground" />
        </div>
        <h1 className="text-2xl font-bold text-foreground">RiderSaarthi AI</h1>
      </div>
      <p className="text-muted-foreground text-sm mb-6">Income protection for delivery partners</p>

      <StepIndicator currentStep={1} steps={["Plan", "Claim", "Payout"]} />

      <div className="w-full rounded-2xl bg-primary/10 flex items-center justify-center py-8 mb-8">
        <div className="text-center">
          <span className="text-5xl">🏍️</span>
          <p className="text-sm font-medium text-primary mt-2">Stay protected, rain or shine</p>
        </div>
      </div>

      <h2 className="text-lg font-semibold text-foreground mb-4 self-start">Choose your plan</h2>
      <div className="w-full space-y-3 mb-8">
        {plans.map((plan) => (
          <button
            key={plan.id}
            onClick={() => setSelected(plan.id)}
            className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all duration-200 bg-card ${
              selected === plan.id
                ? "border-primary shadow-lg shadow-primary/10"
                : "border-border hover:border-muted-foreground/30"
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">{plan.emoji}</span>
              <div className="text-left">
                <p className="font-semibold text-card-foreground">{plan.label} Cover</p>
                <p className="text-xs text-muted-foreground">Up to {plan.coverage}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-primary">₹{plan.price}</p>
              <p className="text-xs text-muted-foreground">/week</p>
            </div>
          </button>
        ))}
      </div>

      <button
        onClick={() => navigate("/status", { state: { plan: selectedPlan } })}
        className="w-full py-4 rounded-xl bg-primary text-primary-foreground font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
      >
        Subscribe to {selectedPlan.label} Cover <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
};

export default Index;
