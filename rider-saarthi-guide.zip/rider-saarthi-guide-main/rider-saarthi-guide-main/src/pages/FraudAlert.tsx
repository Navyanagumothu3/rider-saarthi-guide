import { useNavigate } from "react-router-dom";
import { ShieldAlert, ArrowLeft, Bike } from "lucide-react";

const FraudAlert = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background flex flex-col items-center px-4 py-6 max-w-md mx-auto">
      {/* Header */}
      <div className="flex items-center gap-2 mb-8">
        <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
          <Bike className="w-5 h-5 text-primary-foreground" />
        </div>
        <h1 className="text-xl font-bold text-foreground">RiderSaarthi AI</h1>
      </div>

      {/* Warning icon */}
      <div className="w-20 h-20 rounded-full bg-warning/15 flex items-center justify-center mb-4">
        <ShieldAlert className="w-10 h-10 text-warning" />
      </div>

      <h2 className="text-2xl font-bold text-foreground mb-1">Claim Flagged ⚠️</h2>
      <p className="text-sm text-muted-foreground mb-8">Automated review in progress</p>

      {/* Detail card */}
      <div className="w-full bg-card rounded-2xl border border-warning/30 shadow-lg p-6 mb-6">
        <div className="bg-warning/10 rounded-xl p-4 mb-5">
          <p className="text-sm font-semibold text-foreground mb-1">What happened?</p>
          <p className="text-sm text-muted-foreground">
            Our AI detected an unusual claim pattern — multiple claims from the same zone within 2 hours. Verification is delayed while we cross-check GPS and weather data.
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Claim ID</span>
            <span className="font-medium text-card-foreground">#RS-20260319</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Flag Reason</span>
            <span className="font-medium text-warning">Unusual Pattern</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">ETA</span>
            <span className="font-medium text-card-foreground">~24 hours</span>
          </div>
        </div>
      </div>

      <button
        onClick={() => navigate("/status")}
        className="w-full py-3.5 rounded-xl bg-warning text-warning-foreground font-semibold flex items-center justify-center gap-2 mb-3 active:scale-[0.98] transition-transform"
      >
        I Understand
      </button>
      <button
        onClick={() => navigate("/")}
        className="w-full py-3.5 rounded-xl bg-secondary text-secondary-foreground font-semibold flex items-center justify-center gap-2"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </button>
    </div>
  );
};

export default FraudAlert;
