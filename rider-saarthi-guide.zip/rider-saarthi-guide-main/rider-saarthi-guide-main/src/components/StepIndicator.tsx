import { Check } from "lucide-react";

interface StepIndicatorProps {
  currentStep: number;
  steps: string[];
}

const StepIndicator = ({ currentStep, steps }: StepIndicatorProps) => (
  <div className="w-full flex items-center justify-center gap-1 mb-6">
    {steps.map((label, i) => {
      const step = i + 1;
      const done = step < currentStep;
      const active = step === currentStep;
      return (
        <div key={label} className="flex items-center gap-1">
          <div className="flex flex-col items-center">
            <div
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                done
                  ? "bg-primary text-primary-foreground"
                  : active
                  ? "bg-primary text-primary-foreground ring-2 ring-primary/30"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {done ? <Check className="w-3.5 h-3.5" /> : step}
            </div>
            <span className={`text-[10px] mt-1 ${active ? "font-semibold text-foreground" : "text-muted-foreground"}`}>
              {label}
            </span>
          </div>
          {i < steps.length - 1 && (
            <div className={`w-8 h-0.5 mb-4 rounded ${done ? "bg-primary" : "bg-muted"}`} />
          )}
        </div>
      );
    })}
  </div>
);

export default StepIndicator;
