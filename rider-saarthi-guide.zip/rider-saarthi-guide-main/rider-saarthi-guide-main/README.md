#RiderSaarthi AI – Income Protection for Delivery Partners 🏍️

🧠 What is this project?
RiderSaarthi AI is a mobile-first AI-powered parametric insurance platform for Swiggy/Zomato delivery partners in Hyderabad.
It protects delivery partners from income loss caused by external disruptions like heavy rain 🌧️, traffic jams 🚦, or app downtime 📱.